package roadgraph;

import geography.GeographicPoint;

public class AStarVertex extends ComparableVertex {
	private double estToGoal;
	
	public AStarVertex(Vertex v, GeographicPoint goal) {
		super(v);
		estToGoal = getVertex().getPoint().distance(goal);
	}
	
	public int compareTo(AStarVertex other) {
		double first = this.getDistanceFromStart() + estToGoal;
		double second = other.getDistanceFromStart() + other.estToGoal;
		
		if (first < second) return -1;
		if (first > second) return 1;
		return 0;
		
	}
}
